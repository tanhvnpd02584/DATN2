package com.poly.musicshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusicshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(MusicshopApplication.class, args);
	}

}
