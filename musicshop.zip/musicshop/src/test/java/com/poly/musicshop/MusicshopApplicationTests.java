package com.poly.musicshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MusicshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
